﻿using Advent.Shared.Attributes;
using Advent.Shared.Models;

namespace $rootnamespace$;

[TestClass]
[Puzzle(2015, 1)]
public sealed class $safeitemname$ : AdventTestBase
{
    [TestMethod]
    public void P01()
    {
        Assert.Inconclusive("Part 1 not implemented.");
    }

    [TestMethod]
    public void P02()
    {
        Assert.Inconclusive("Part 2 not implemented.");
    }
}
